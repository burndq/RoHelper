import re
from typing import Dict, List, Optional, Any

class ScriptTemplates:
    """Manages Roblox script templates and generation"""
    
    def __init__(self):
        self.categories = [
            {"id": "basic", "name": "Basic Scripts"},
            {"id": "gui", "name": "GUI Scripts"},
            {"id": "tools", "name": "Tool Scripts"},
            {"id": "gameplay", "name": "Gameplay Scripts"},
            {"id": "effects", "name": "Effects & Animation"}
        ]
        
        self.templates = {
            # Basic Scripts
            "hello_world": {
                "id": "hello_world",
                "name": "Hello World",
                "description": "Basic print statement",
                "category": "basic",
                "code": '''-- Hello World Script
print("Hello, Roblox!")
print("This is my first script!")'''
            },
            
            "basic_part": {
                "id": "basic_part",
                "name": "Create Basic Part",
                "description": "Creates a simple part in workspace",
                "category": "basic",
                "code": '''-- Create a Basic Part
local part = Instance.new("Part")
part.Name = "MyPart"
part.BrickColor = BrickColor.new("Bright red")
part.Material = Enum.Material.Neon
part.Size = Vector3.new(4, 1, 2)
part.Position = Vector3.new(0, 10, 0)
part.Anchored = true
part.Parent = workspace

print("Part created!")'''
            },
            
            # GUI Scripts
            "simple_gui": {
                "id": "simple_gui",
                "name": "Simple GUI",
                "description": "Basic ScreenGui with button",
                "category": "gui",
                "code": '''-- Simple GUI Script
local Players = game:GetService("Players")
local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

-- Create ScreenGui
local screenGui = Instance.new("ScreenGui")
screenGui.Name = "MyGui"
screenGui.Parent = playerGui

-- Create Frame
local frame = Instance.new("Frame")
frame.Name = "MainFrame"
frame.Size = UDim2.new(0, 300, 0, 200)
frame.Position = UDim2.new(0.5, -150, 0.5, -100)
frame.BackgroundColor3 = Color3.fromRGB(0, 162, 255)
frame.BorderSizePixel = 0
frame.Parent = screenGui

-- Create Button
local button = Instance.new("TextButton")
button.Name = "ClickButton"
button.Size = UDim2.new(0, 200, 0, 50)
button.Position = UDim2.new(0.5, -100, 0.5, -25)
button.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
button.Text = "Click Me!"
button.TextColor3 = Color3.fromRGB(0, 0, 0)
button.TextScaled = true
button.Parent = frame

-- Button click function
button.MouseButton1Click:Connect(function()
    print("Button clicked!")
    button.Text = "Clicked!"
    wait(1)
    button.Text = "Click Me!"
end)'''
            },
            
            # Tool Scripts
            "basic_tool": {
                "id": "basic_tool",
                "name": "Basic Tool",
                "description": "Simple tool that can be equipped",
                "category": "tools",
                "code": '''-- Basic Tool Script
local tool = script.Parent
local players = game:GetService("Players")

local function onEquipped()
    print("Tool equipped!")
end

local function onUnequipped()
    print("Tool unequipped!")
end

local function onActivated()
    print("Tool activated!")
    -- Add your tool functionality here
end

tool.Equipped:Connect(onEquipped)
tool.Unequipped:Connect(onUnequipped)
tool.Activated:Connect(onActivated)'''
            },
            
            # Gameplay Scripts
            "teleporter": {
                "id": "teleporter",
                "name": "Teleporter Pad",
                "description": "Teleports player when touched",
                "category": "gameplay",
                "code": '''-- Teleporter Script
local teleporter = script.Parent
local teleportPosition = Vector3.new(0, 50, 0) -- Change this to your desired position

local function onTouched(hit)
    local humanoid = hit.Parent:FindFirstChild("Humanoid")
    if humanoid then
        local player = game.Players:GetPlayerFromCharacter(hit.Parent)
        if player then
            -- Teleport the player
            hit.Parent.HumanoidRootPart.Position = teleportPosition
            print(player.Name .. " has been teleported!")
        end
    end
end

teleporter.Touched:Connect(onTouched)'''
            },
            
            "kill_brick": {
                "id": "kill_brick",
                "name": "Kill Brick",
                "description": "Removes player's character when touched",
                "category": "gameplay",
                "code": '''-- Kill Brick Script
local killBrick = script.Parent

local function onTouched(hit)
    local humanoid = hit.Parent:FindFirstChild("Humanoid")
    if humanoid then
        local player = game.Players:GetPlayerFromCharacter(hit.Parent)
        if player then
            print(player.Name .. " touched the kill brick!")
            hit.Parent.Humanoid.Health = 0
        end
    end
end

killBrick.Touched:Connect(onTouched)'''
            },
            
            # Effects & Animation
            "spinning_part": {
                "id": "spinning_part",
                "name": "Spinning Part",
                "description": "Makes a part spin continuously",
                "category": "effects",
                "code": '''-- Spinning Part Script
local part = script.Parent
local runService = game:GetService("RunService")

local spinSpeed = 5 -- Degrees per frame

local function spinPart()
    part.CFrame = part.CFrame * CFrame.Angles(0, math.rad(spinSpeed), 0)
end

-- Connect to Heartbeat for smooth animation
runService.Heartbeat:Connect(spinPart)'''
            },
            
            "color_changer": {
                "id": "color_changer",
                "name": "Color Changer",
                "description": "Changes part color randomly",
                "category": "effects",
                "code": '''-- Color Changer Script
local part = script.Parent
local colors = {
    BrickColor.new("Bright red"),
    BrickColor.new("Bright blue"),
    BrickColor.new("Bright green"),
    BrickColor.new("Bright yellow"),
    BrickColor.new("Bright violet"),
    BrickColor.new("Bright orange")
}

local function changeColor()
    local randomColor = colors[math.random(1, #colors)]
    part.BrickColor = randomColor
end

-- Change color every 2 seconds
while true do
    changeColor()
    wait(2)
end'''
            }
        }
    
    def get_categories(self) -> List[Dict[str, str]]:
        """Get all script categories"""
        return self.categories
    
    def get_templates_by_category(self, category: str) -> List[Dict[str, Any]]:
        """Get all templates for a specific category"""
        templates = []
        for template in self.templates.values():
            if template["category"] == category:
                templates.append({
                    "id": template["id"],
                    "name": template["name"],
                    "description": template["description"]
                })
        return templates
    
    def get_template(self, template_id: str) -> Optional[Dict[str, Any]]:
        """Get a specific template by ID"""
        return self.templates.get(template_id)
    
    def generate_script(self, script_type: str, options: Dict[str, Any]) -> str:
        """Generate a custom script based on type and options"""
        object_name = options.get("objectName", "MyObject")
        
        if script_type == "basic":
            return f'''-- Basic Script for {object_name}
print("Hello from {object_name}!")

-- Add your code here
'''
        
        elif script_type == "gui":
            gui_type = options.get("guiType", "ScreenGui")
            button_text = options.get("buttonText", "Click Me")
            
            return f'''-- GUI Script for {object_name}
local Players = game:GetService("Players")
local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

-- Create {gui_type}
local gui = Instance.new("{gui_type}")
gui.Name = "{object_name}"
gui.Parent = playerGui

-- Create Frame
local frame = Instance.new("Frame")
frame.Name = "MainFrame"
frame.Size = UDim2.new(0, 300, 0, 200)
frame.Position = UDim2.new(0.5, -150, 0.5, -100)
frame.BackgroundColor3 = Color3.fromRGB(0, 162, 255)
frame.Parent = gui

-- Create Button
local button = Instance.new("TextButton")
button.Name = "MainButton"
button.Size = UDim2.new(0, 200, 0, 50)
button.Position = UDim2.new(0.5, -100, 0.5, -25)
button.Text = "{button_text}"
button.TextScaled = true
button.Parent = frame

button.MouseButton1Click:Connect(function()
    print("{object_name} button clicked!")
end)
'''
        
        elif script_type == "tool":
            requires_handle = options.get("requiresHandle", True)
            can_be_dropped = options.get("canBeDropped", True)
            
            return f'''-- Tool Script for {object_name}
local tool = script.Parent
tool.Name = "{object_name}"
tool.RequiresHandle = {str(requires_handle).lower()}
tool.CanBeDropped = {str(can_be_dropped).lower()}

local function onEquipped()
    print("{object_name} equipped!")
end

local function onUnequipped()
    print("{object_name} unequipped!")
end

local function onActivated()
    print("{object_name} activated!")
    -- Add your tool functionality here
end

tool.Equipped:Connect(onEquipped)
tool.Unequipped:Connect(onUnequipped)
tool.Activated:Connect(onActivated)
'''
        
        elif script_type == "part_spawner":
            part_shape = options.get("partShape", "Block")
            material = options.get("material", "Plastic")
            color = options.get("color", "Bright red")
            
            return f'''-- Part Spawner Script for {object_name}
local function createPart()
    local part = Instance.new("Part")
    part.Name = "{object_name}_Part"
    part.Shape = Enum.PartType.{part_shape}
    part.Material = Enum.Material.{material}
    part.BrickColor = BrickColor.new("{color}")
    part.Size = Vector3.new(4, 4, 4)
    part.Position = Vector3.new(math.random(-20, 20), 10, math.random(-20, 20))
    part.Parent = workspace
    
    print("Created " .. part.Name)
end

-- Create a part every 5 seconds
while true do
    createPart()
    wait(5)
end
'''
        
        elif script_type == "teleporter":
            pos_x = options.get("posX", 0)
            pos_y = options.get("posY", 50)
            pos_z = options.get("posZ", 0)
            
            return f'''-- Teleporter Script for {object_name}
local teleporter = script.Parent
local teleportPosition = Vector3.new({pos_x}, {pos_y}, {pos_z})

local function onTouched(hit)
    local humanoid = hit.Parent:FindFirstChild("Humanoid")
    if humanoid then
        local player = game.Players:GetPlayerFromCharacter(hit.Parent)
        if player then
            hit.Parent.HumanoidRootPart.Position = teleportPosition
            print(player.Name .. " teleported by {object_name}!")
        end
    end
end

teleporter.Touched:Connect(onTouched)
'''
        
        elif script_type == "animation":
            return f'''-- Animation Controller for {object_name}
local part = script.Parent
local runService = game:GetService("RunService")

-- Animation variables
local time = 0
local speed = 1

local function animate()
    time = time + (speed * runService.Heartbeat:Wait())
    
    -- Simple floating animation
    local newY = part.Position.Y + math.sin(time) * 0.5
    part.Position = Vector3.new(part.Position.X, newY, part.Position.Z)
    
    -- Rotation animation
    part.CFrame = part.CFrame * CFrame.Angles(0, math.rad(1), 0)
end

runService.Heartbeat:Connect(animate)
print("{object_name} animation started!")
'''
        
        else:
            raise ValueError(f"Unknown script type: {script_type}")
    
    def validate_lua_script(self, code: str) -> Dict[str, Any]:
        """Basic Lua script validation for Roblox"""
        errors = []
        warnings = []
        suggestions = []
        
        lines = code.split('\n')
        
        # Check for basic syntax issues
        open_blocks = 0
        in_string = False
        string_char = None
        
        for i, line in enumerate(lines, 1):
            line_stripped = line.strip()
            
            # Skip empty lines and comments
            if not line_stripped or line_stripped.startswith('--'):
                continue
            
            # Basic bracket matching
            for char in line:
                if char in ['"', "'"] and not in_string:
                    in_string = True
                    string_char = char
                elif char == string_char and in_string:
                    in_string = False
                    string_char = None
                elif not in_string:
                    if char in ['(', '[', '{']:
                        open_blocks += 1
                    elif char in [')', ']', '}']:
                        open_blocks -= 1
                        if open_blocks < 0:
                            errors.append(f"Line {i}: Unmatched closing bracket")
            
            # Check for common Roblox patterns
            if 'wait(' in line and not 'task.wait(' in line:
                warnings.append(f"Line {i}: Consider using task.wait() instead of wait() for better performance")
            
            if 'while true do' in line and 'wait' not in line:
                errors.append(f"Line {i}: Infinite loop detected without wait - this will crash the server")
            
            if 'game.Players.LocalPlayer' in line:
                suggestions.append(f"Line {i}: This looks like a LocalScript - make sure it's placed correctly")
            
            if re.search(r'\.Parent\s*=.*workspace', line):
                suggestions.append(f"Line {i}: Consider using more specific parent references")
        
        # Final bracket check
        if open_blocks > 0:
            errors.append(f"Unmatched opening brackets - missing {open_blocks} closing bracket(s)")
        
        # Check for common issues
        if 'Instance.new' in code and 'Parent' not in code:
            warnings.append("Created instances should be parented to be visible")
        
        if len(code.strip()) == 0:
            errors.append("Script is empty")
        
        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings,
            "suggestions": suggestions
        }
