// Main JavaScript for Roblox Script Generator

let codeEditor;
let currentTemplate = null;

function initializeApp() {
    // Initialize CodeMirror
    initializeCodeEditor();
    
    // Load templates for all categories
    loadAllTemplates();
    
    // Set up event listeners
    setupEventListeners();
}

function initializeCodeEditor() {
    const textarea = document.getElementById('codeEditor');
    codeEditor = CodeMirror.fromTextArea(textarea, {
        mode: 'lua',
        theme: 'monokai',
        lineNumbers: true,
        autoCloseBrackets: true,
        matchBrackets: true,
        indentUnit: 4,
        tabSize: 4,
        lineWrapping: true
    });
}

function loadAllTemplates() {
    const templateLists = document.querySelectorAll('.template-list');
    
    templateLists.forEach(list => {
        const category = list.dataset.category;
        loadTemplatesForCategory(category, list);
    });
}

async function loadTemplatesForCategory(category, container) {
    try {
        const response = await fetch(`/api/templates/${category}`);
        const templates = await response.json();
        
        if (templates.length === 0) {
            container.innerHTML = '<div class="text-muted small">No templates available</div>';
            return;
        }
        
        const templateHtml = templates.map(template => `
            <div class="template-item" data-template-id="${template.id}">
                <div class="fw-bold">${template.name}</div>
                <div class="text-muted small">${template.description}</div>
            </div>
        `).join('');
        
        container.innerHTML = templateHtml;
        
        // Add click handlers
        container.querySelectorAll('.template-item').forEach(item => {
            item.addEventListener('click', () => loadTemplate(item.dataset.templateId));
        });
        
    } catch (error) {
        console.error('Error loading templates:', error);
        container.innerHTML = '<div class="text-danger small">Error loading templates</div>';
    }
}

async function loadTemplate(templateId) {
    try {
        const response = await fetch(`/api/template/${templateId}`);
        const template = await response.json();
        
        if (template.error) {
            showNotification('Error loading template', 'error');
            return;
        }
        
        // Update editor
        codeEditor.setValue(template.code);
        
        // Update script info
        const scriptInfo = document.getElementById('scriptInfo');
        const scriptTitle = document.getElementById('scriptTitle');
        const scriptDescription = document.getElementById('scriptDescription');
        
        scriptTitle.textContent = template.name;
        scriptDescription.textContent = template.description;
        scriptInfo.style.display = 'block';
        
        // Update selected template
        document.querySelectorAll('.template-item.selected').forEach(item => {
            item.classList.remove('selected');
        });
        document.querySelector(`[data-template-id="${templateId}"]`).classList.add('selected');
        
        currentTemplate = template;
        
    } catch (error) {
        console.error('Error loading template:', error);
        showNotification('Error loading template', 'error');
    }
}

function setupEventListeners() {
    // Copy button
    document.getElementById('copyBtn').addEventListener('click', copyToClipboard);
    
    // Validate button
    document.getElementById('validateBtn').addEventListener('click', validateScript);
    
    // Generate form
    document.getElementById('generateForm').addEventListener('submit', generateCustomScript);
    
    // Script type change
    document.getElementById('scriptType').addEventListener('change', updateCustomOptions);
    
    // Initialize custom options
    updateCustomOptions();
}

async function copyToClipboard() {
    const code = codeEditor.getValue();
    
    try {
        await navigator.clipboard.writeText(code);
        showNotification('Script copied to clipboard!', 'success');
        
        // Visual feedback
        document.getElementById('copyBtn').classList.add('copy-success');
        setTimeout(() => {
            document.getElementById('copyBtn').classList.remove('copy-success');
        }, 500);
        
    } catch (error) {
        console.error('Error copying to clipboard:', error);
        
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = code;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        
        showNotification('Script copied to clipboard!', 'success');
    }
}

async function validateScript() {
    const code = codeEditor.getValue();
    
    if (!code.trim()) {
        showNotification('Please enter some code to validate', 'warning');
        return;
    }
    
    try {
        const response = await fetch('/api/validate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ code })
        });
        
        const result = await response.json();
        showValidationResults(result);
        
    } catch (error) {
        console.error('Error validating script:', error);
        showNotification('Error validating script', 'error');
    }
}

function showValidationResults(result) {
    const modal = new bootstrap.Modal(document.getElementById('validationModal'));
    const resultsContainer = document.getElementById('validationResults');
    
    let html = `
        <div class="validation-summary mb-3">
            <h6>Validation Summary</h6>
            <div class="d-flex justify-content-between">
                <span>Status: </span>
                <span class="${result.valid ? 'validation-success' : 'validation-error'}">
                    <i class="fas ${result.valid ? 'fa-check' : 'fa-times'}"></i>
                    ${result.valid ? 'Valid' : 'Has Issues'}
                </span>
            </div>
        </div>
    `;
    
    if (result.errors && result.errors.length > 0) {
        html += `
            <div class="mb-3">
                <h6 class="validation-error"><i class="fas fa-exclamation-triangle"></i> Errors</h6>
                <ul class="list-unstyled">
                    ${result.errors.map(error => `<li class="validation-error">• ${error}</li>`).join('')}
                </ul>
            </div>
        `;
    }
    
    if (result.warnings && result.warnings.length > 0) {
        html += `
            <div class="mb-3">
                <h6 class="validation-warning"><i class="fas fa-exclamation"></i> Warnings</h6>
                <ul class="list-unstyled">
                    ${result.warnings.map(warning => `<li class="validation-warning">• ${warning}</li>`).join('')}
                </ul>
            </div>
        `;
    }
    
    if (result.suggestions && result.suggestions.length > 0) {
        html += `
            <div class="mb-3">
                <h6 class="text-info"><i class="fas fa-lightbulb"></i> Suggestions</h6>
                <ul class="list-unstyled">
                    ${result.suggestions.map(suggestion => `<li class="text-info">• ${suggestion}</li>`).join('')}
                </ul>
            </div>
        `;
    }
    
    resultsContainer.innerHTML = html;
    modal.show();
}

async function generateCustomScript(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const scriptType = document.getElementById('scriptType').value;
    const objectName = document.getElementById('objectName').value;
    
    const options = {
        objectName: objectName || 'MyObject'
    };
    
    // Collect custom options
    document.querySelectorAll('#customOptions input, #customOptions select').forEach(input => {
        options[input.name] = input.type === 'checkbox' ? input.checked : input.value;
    });
    
    try {
        const response = await fetch('/api/generate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                type: scriptType,
                options: options
            })
        });
        
        const result = await response.json();
        
        if (result.error) {
            showNotification(result.error, 'error');
            return;
        }
        
        codeEditor.setValue(result.script);
        showNotification('Custom script generated successfully!', 'success');
        
        // Hide script info panel
        document.getElementById('scriptInfo').style.display = 'none';
        
    } catch (error) {
        console.error('Error generating script:', error);
        showNotification('Error generating script', 'error');
    }
}

function updateCustomOptions() {
    const scriptType = document.getElementById('scriptType').value;
    const optionsContainer = document.getElementById('customOptions');
    
    let optionsHtml = '';
    
    switch (scriptType) {
        case 'gui':
            optionsHtml = `
                <div class="option-group">
                    <h6>GUI Options</h6>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="form-label">GUI Type</label>
                            <select name="guiType" class="form-select">
                                <option value="ScreenGui">ScreenGui</option>
                                <option value="SurfaceGui">SurfaceGui</option>
                                <option value="BillboardGui">BillboardGui</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Button Text</label>
                            <input type="text" name="buttonText" class="form-control" value="Click Me">
                        </div>
                    </div>
                </div>
            `;
            break;
            
        case 'tool':
            optionsHtml = `
                <div class="option-group">
                    <h6>Tool Options</h6>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-check">
                                <input type="checkbox" name="requiresHandle" class="form-check-input" checked>
                                <label class="form-check-label">Requires Handle</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-check">
                                <input type="checkbox" name="canBeDropped" class="form-check-input" checked>
                                <label class="form-check-label">Can Be Dropped</label>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            break;
            
        case 'part_spawner':
            optionsHtml = `
                <div class="option-group">
                    <h6>Part Spawner Options</h6>
                    <div class="row">
                        <div class="col-md-4">
                            <label class="form-label">Part Shape</label>
                            <select name="partShape" class="form-select">
                                <option value="Block">Block</option>
                                <option value="Ball">Ball</option>
                                <option value="Cylinder">Cylinder</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Material</label>
                            <select name="material" class="form-select">
                                <option value="Plastic">Plastic</option>
                                <option value="Metal">Metal</option>
                                <option value="Wood">Wood</option>
                                <option value="Neon">Neon</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Color</label>
                            <select name="color" class="form-select">
                                <option value="Bright red">Bright Red</option>
                                <option value="Bright blue">Bright Blue</option>
                                <option value="Bright green">Bright Green</option>
                                <option value="Really black">Really Black</option>
                            </select>
                        </div>
                    </div>
                </div>
            `;
            break;
            
        case 'teleporter':
            optionsHtml = `
                <div class="option-group">
                    <h6>Teleporter Options</h6>
                    <div class="row">
                        <div class="col-md-4">
                            <label class="form-label">X Position</label>
                            <input type="number" name="posX" class="form-control" value="0">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Y Position</label>
                            <input type="number" name="posY" class="form-control" value="50">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Z Position</label>
                            <input type="number" name="posZ" class="form-control" value="0">
                        </div>
                    </div>
                </div>
            `;
            break;
    }
    
    optionsContainer.innerHTML = optionsHtml;
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show position-fixed`;
    notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; max-width: 300px;';
    
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}
