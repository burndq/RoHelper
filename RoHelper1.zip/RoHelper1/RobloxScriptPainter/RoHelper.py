#!/usr/bin/env python3
"""
RoHelper - Professional Roblox Script Generator
Apple-inspired liquid glass design with clean typography
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext

import json
import threading

import os
import time
import re
from typing import Dict, List, Optional

class RoHelper:
    """RoHelper with Apple-inspired liquid glass design"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("RoHelper")
        self.root.geometry("1200x800")
        self.root.minsize(1000, 700)
        
        # Apple-inspired light background
        self.root.configure(bg="#f5f5f7")
        
        # Apple color palette
        self.colors = {
            'bg_primary': '#f5f5f7',
            'bg_glass': '#ffffff',
            'text_primary': '#1d1d1f',
            'text_secondary': '#86868b',
            'accent': '#007aff',
            'success': '#30d158',
            'warning': '#ff9f0a',
            'error': '#ff3b30'
        }
        
        # Load templates
        self.templates = self.load_templates()
        
        # Studio settings
        self.studio_port = 24872
        self.studio_host = "localhost"
        self.transfer_folder = "rohelper_scripts"
        
        if not os.path.exists(self.transfer_folder):
            os.makedirs(self.transfer_folder)
        
        self.setup_ui()
    
    def load_templates(self) -> Dict:
        """Load clean script templates"""
        return {
            "Basic Scripts": {
                "Hello World": {
                    "description": "Simple greeting script perfect for beginners",
                    "code": '''-- Hello World Script
print("Hello, Roblox!")
print("Created with RoHelper")
print("Professional scripting made simple")'''
                },
                "Create Part": {
                    "description": "Creates a beautiful part with lighting",
                    "code": '''-- Create Beautiful Part
local part = Instance.new("Part")
part.Name = "RoHelper_Part"
part.BrickColor = BrickColor.new("Bright blue")
part.Material = Enum.Material.Glass
part.Size = Vector3.new(6, 1, 6)
part.Position = Vector3.new(0, 15, 0)
part.Anchored = true
part.Parent = workspace

-- Add elegant lighting
local light = Instance.new("PointLight")
light.Brightness = 1.5
light.Color = Color3.fromRGB(135, 206, 250)
light.Range = 12
light.Parent = part

print("Beautiful part created with RoHelper")'''
                }
            },
            "GUI Scripts": {
                "Modern Interface": {
                    "description": "Clean, modern GUI with glass effects",
                    "code": '''-- Modern GUI Interface
local Players = game:GetService("Players")
local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

-- Create main GUI
local screenGui = Instance.new("ScreenGui")
screenGui.Name = "RoHelper_ModernGUI"
screenGui.Parent = playerGui

-- Glass-effect container
local mainFrame = Instance.new("Frame")
mainFrame.Size = UDim2.new(0, 380, 0, 280)
mainFrame.Position = UDim2.new(0.5, -190, 0.5, -140)
mainFrame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
mainFrame.BackgroundTransparency = 0.05
mainFrame.BorderSizePixel = 0
mainFrame.Parent = screenGui

-- Rounded corners
local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 16)
corner.Parent = mainFrame

-- Clean header
local header = Instance.new("TextLabel")
header.Size = UDim2.new(1, 0, 0, 60)
header.BackgroundTransparency = 1
header.Text = "RoHelper Panel"
header.TextColor3 = Color3.fromRGB(29, 29, 31)
header.TextSize = 24
header.Font = Enum.Font.SourceSans
header.Parent = mainFrame

-- Action button
local button = Instance.new("TextButton")
button.Size = UDim2.new(0, 200, 0, 44)
button.Position = UDim2.new(0.5, -100, 0.7, -22)
button.BackgroundColor3 = Color3.fromRGB(0, 122, 255)
button.Text = "Activate"
button.TextColor3 = Color3.fromRGB(255, 255, 255)
button.TextSize = 18
button.Font = Enum.Font.SourceSans
button.BorderSizePixel = 0
button.Parent = mainFrame

local buttonCorner = Instance.new("UICorner")
buttonCorner.CornerRadius = UDim.new(0, 8)
buttonCorner.Parent = button

print("Modern GUI created with RoHelper")'''
                }
            },
            "Tool Scripts": {
                "Magic Wand": {
                    "description": "Elegant magic tool with smooth effects",
                    "code": '''-- Magic Wand Tool
local tool = script.Parent
tool.Name = "RoHelper_MagicWand"
tool.RequiresHandle = true

local Players = game:GetService("Players")
local player = Players.LocalPlayer

local function createEffect(position)
    local effect = Instance.new("Part")
    effect.Size = Vector3.new(0.5, 0.5, 0.5)
    effect.Position = position
    effect.Material = Enum.Material.Glass
    effect.BrickColor = BrickColor.new("Bright blue")
    effect.Anchored = true
    effect.CanCollide = false
    effect.Parent = workspace
    
    -- Smooth glow
    local light = Instance.new("PointLight")
    light.Brightness = 2
    light.Color = Color3.fromRGB(135, 206, 250)
    light.Parent = effect
    
    game:GetService("Debris"):AddItem(effect, 1)
end

tool.Activated:Connect(function()
    if player.Character then
        local rootPart = player.Character.HumanoidRootPart
        local magicPos = rootPart.Position + rootPart.CFrame.LookVector * 8
        createEffect(magicPos)
    end
end)

print("Magic Wand created with RoHelper")'''
                }
            },
            "Effects Scripts": {
                "Particle System": {
                    "description": "Beautiful particle effects",
                    "code": '''-- Elegant Particle System
local effectPart = script.Parent

-- Create attachment
local attachment = Instance.new("Attachment")
attachment.Parent = effectPart

local particles = Instance.new("ParticleEmitter")
particles.Parent = attachment

-- Configure beautiful particles
particles.Texture = "rbxasset://textures/particles/sparkles_main.dds"
particles.Lifetime = NumberRange.new(1.5, 3.0)
particles.Rate = 25
particles.SpreadAngle = Vector2.new(20, 20)
particles.Speed = NumberRange.new(8, 15)

-- Soft colors
particles.Color = ColorSequence.new{
    ColorSequenceKeypoint.new(0, Color3.fromRGB(135, 206, 250)),
    ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 255, 255))
}

-- Smooth size animation
particles.Size = NumberSequence.new{
    NumberSequenceKeypoint.new(0, 0.3),
    NumberSequenceKeypoint.new(0.5, 0.8),
    NumberSequenceKeypoint.new(1, 0)
}

print("Particle system created with RoHelper")'''
                }
            }
        }
    
    def create_glass_header(self):
        """Create Apple-style translucent header"""
        # Main header with glass effect
        header_frame = tk.Frame(self.root, bg="white", height=100, relief='flat')
        header_frame.pack(fill=tk.X)
        header_frame.pack_propagate(False)
        
        # Subtle shadow line
        shadow_line = tk.Frame(self.root, bg="#e5e5ea", height=1)
        shadow_line.pack(fill=tk.X)
        
        # Content with Apple spacing
        content_frame = tk.Frame(header_frame, bg="white")
        content_frame.pack(fill=tk.BOTH, expand=True, padx=40, pady=25)
        
        # Left: App title
        left_frame = tk.Frame(content_frame, bg="white")
        left_frame.pack(side=tk.LEFT, fill=tk.Y)
        
        title_label = tk.Label(left_frame, text="RoHelper", 
                              font=('Helvetica Neue', 32, 'normal'), 
                              bg="white", fg="#1d1d1f")
        title_label.pack(anchor=tk.W)
        
        subtitle_label = tk.Label(left_frame, text="Roblox Script Generator", 
                                 font=('Helvetica Neue', 14), 
                                 bg="white", fg="#86868b")
        subtitle_label.pack(anchor=tk.W)
        
        # Right: Status
        right_frame = tk.Frame(content_frame, bg="white")
        right_frame.pack(side=tk.RIGHT, fill=tk.Y)
        
        status_frame = tk.Frame(right_frame, bg="white")
        status_frame.pack(anchor=tk.E)
        
        status_dot = tk.Label(status_frame, text="●", 
                             font=('Helvetica Neue', 18), 
                             bg="white", fg="#30d158")
        status_dot.pack(side=tk.LEFT)
        
        status_text = tk.Label(status_frame, text="Ready", 
                              font=('Helvetica Neue', 13), 
                              bg="white", fg="#86868b")
        status_text.pack(side=tk.LEFT, padx=(8, 0))
    
    def setup_ui(self):
        """Setup Apple-inspired interface"""
        # Create header
        self.create_glass_header()
        
        # Main content with Apple spacing
        main_frame = tk.Frame(self.root, bg="#f5f5f7")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=30, pady=30)
        
        # Left panel (35%)
        left_frame = tk.Frame(main_frame, bg="#f5f5f7")
        left_frame.pack(side=tk.LEFT, fill=tk.Y)
        left_frame.config(width=350)
        left_frame.pack_propagate(False)
        
        self.setup_template_panel(left_frame)
        
        # Right panel (65%)
        right_frame = tk.Frame(main_frame, bg="#f5f5f7")
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(20, 0))
        
        self.setup_editor_panel(right_frame)
        self.setup_studio_panel(right_frame)
    
    def setup_template_panel(self, parent):
        """Apple-style template panel"""
        # Glass container
        container = tk.Frame(parent, bg="white", relief='solid', borderwidth=1)
        container.pack(fill=tk.BOTH, expand=True)
        container.configure(highlightbackground="#e5e5ea", highlightthickness=0)
        
        # Header
        header = tk.Label(container, text="Templates",
                         font=('Helvetica Neue', 18, 'normal'),
                         bg="white", fg="#1d1d1f")
        header.pack(pady=(25, 15))
        
        # Content frame
        content = tk.Frame(container, bg="white")
        content.pack(fill=tk.BOTH, expand=True, padx=25, pady=(0, 25))
        
        # Category
        cat_label = tk.Label(content, text="Category",
                            font=('Helvetica Neue', 13),
                            bg="white", fg="#1d1d1f")
        cat_label.pack(anchor=tk.W, pady=(0, 8))
        
        self.category_var = tk.StringVar()
        self.category_combo = ttk.Combobox(content, textvariable=self.category_var,
                                          values=list(self.templates.keys()), 
                                          state="readonly", font=('Helvetica Neue', 12))
        self.category_combo.pack(fill=tk.X, pady=(0, 20))
        self.category_combo.bind('<<ComboboxSelected>>', self.on_category_change)
        
        # Template list
        list_label = tk.Label(content, text="Scripts",
                             font=('Helvetica Neue', 13),
                             bg="white", fg="#1d1d1f")
        list_label.pack(anchor=tk.W, pady=(0, 8))
        
        list_frame = tk.Frame(content, bg="#fbfbfd", relief='solid', borderwidth=1)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 20))
        
        self.template_listbox = tk.Listbox(list_frame,
                                          bg="#fbfbfd", fg="#1d1d1f",
                                          selectbackground="#007aff", selectforeground="white",
                                          font=('Helvetica Neue', 12), relief="flat",
                                          borderwidth=0, highlightthickness=0)
        
        scrollbar = tk.Scrollbar(list_frame, command=self.template_listbox.yview,
                               bg="#f0f0f0", troughcolor="#f8f8f8")
        self.template_listbox.configure(yscrollcommand=scrollbar.set)
        
        self.template_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=2, pady=2)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y, padx=(0, 2), pady=2)
        
        self.template_listbox.bind('<<ListboxSelect>>', self.on_template_select)
        self.template_listbox.bind('<Double-Button-1>', self.on_template_select)
        
        # Description
        desc_label = tk.Label(content, text="Description",
                             font=('Helvetica Neue', 13),
                             bg="white", fg="#1d1d1f")
        desc_label.pack(anchor=tk.W, pady=(0, 8))
        
        self.description_label = tk.Label(content, 
                                         text="Select a template to see description",
                                         font=('Helvetica Neue', 11),
                                         bg="white", fg="#86868b",
                                         wraplength=300, justify=tk.LEFT)
        self.description_label.pack(anchor=tk.W, fill=tk.X, pady=(0, 15))
        
        # Tip
        tip = tk.Label(content, text="Tip: Double-click to load instantly",
                      font=('Helvetica Neue', 10),
                      bg="white", fg="#86868b")
        tip.pack(anchor=tk.W)
        
        # Initialize
        if self.templates:
            self.category_combo.set(list(self.templates.keys())[0])
            self.on_category_change()
    
    def setup_editor_panel(self, parent):
        """Apple-style code editor"""
        # Glass container
        editor_container = tk.Frame(parent, bg="white", relief='solid', borderwidth=1)
        editor_container.pack(fill=tk.BOTH, expand=True, pady=(0, 20))
        editor_container.configure(highlightbackground="#e5e5ea", highlightthickness=0)
        
        # Header
        editor_header = tk.Label(editor_container, text="Script Editor",
                                font=('Helvetica Neue', 18, 'normal'),
                                bg="white", fg="#1d1d1f")
        editor_header.pack(pady=(25, 15))
        
        # Content frame
        content = tk.Frame(editor_container, bg="white")
        content.pack(fill=tk.BOTH, expand=True, padx=25, pady=(0, 25))
        
        # Toolbar
        toolbar = tk.Frame(content, bg="white")
        toolbar.pack(fill=tk.X, pady=(0, 20))
        
        # Left buttons
        left_buttons = tk.Frame(toolbar, bg="white")
        left_buttons.pack(side=tk.LEFT)
        
        clear_btn = tk.Button(left_buttons, text="Clear",
                             font=('Helvetica Neue', 11), bg="white", fg="#1d1d1f",
                             relief='solid', borderwidth=1, padx=15, pady=6,
                             activebackground="#f0f0f0", cursor="hand2",
                             command=self.clear_editor)
        clear_btn.pack(side=tk.LEFT, padx=(0, 12))
        
        copy_btn = tk.Button(left_buttons, text="Copy",
                            font=('Helvetica Neue', 11), bg="white", fg="#1d1d1f",
                            relief='solid', borderwidth=1, padx=15, pady=6,
                            activebackground="#f0f0f0", cursor="hand2",
                            command=self.copy_to_clipboard)
        copy_btn.pack(side=tk.LEFT, padx=(0, 12))
        
        generate_btn = tk.Button(left_buttons, text="Generate",
                                font=('Helvetica Neue', 11), bg="white", fg="#1d1d1f",
                                relief='solid', borderwidth=1, padx=15, pady=6,
                                activebackground="#f0f0f0", cursor="hand2",
                                command=self.generate_custom_script)
        generate_btn.pack(side=tk.LEFT)
        
        # Primary button
        right_buttons = tk.Frame(toolbar, bg="white")
        right_buttons.pack(side=tk.RIGHT)
        
        self.send_button = tk.Button(right_buttons, text="Send to Studio",
                                   font=('Helvetica Neue', 12, 'normal'),
                                   bg="#007aff", fg="white", relief='flat',
                                   borderwidth=0, padx=25, pady=10,
                                   activebackground="#0051d5",
                                   cursor="hand2", command=self.send_to_studio)
        self.send_button.pack()
        
        # Code editor
        editor_frame = tk.Frame(content, bg="#fbfbfd", relief='solid', borderwidth=1)
        editor_frame.pack(fill=tk.BOTH, expand=True)
        editor_frame.configure(highlightbackground="#e5e5ea", highlightthickness=1)
        
        self.code_editor = scrolledtext.ScrolledText(editor_frame, wrap=tk.NONE,
                                                   font=("Monaco", 14),
                                                   bg="#fbfbfd", fg="#1d1d1f",
                                                   insertbackground="#007aff",
                                                   selectbackground="#b3d7ff",
                                                   selectforeground="#1d1d1f",
                                                   relief="flat", borderwidth=0,
                                                   padx=20, pady=20)
        self.code_editor.pack(fill=tk.BOTH, expand=True)
        
        # Setup highlighting
        self.setup_syntax_highlighting()
        
        # Welcome message
        welcome = '''-- Welcome to RoHelper
-- Select a template from the left for instant code
-- Use "Generate" for custom scripts
-- Click "Send to Studio" to transfer
--
-- Tips:
-- • Double-click templates for instant loading  
-- • Scripts are saved to rohelper_scripts folder
-- • Use clear names for organization

print("Welcome to RoHelper")
print("Professional Roblox scripting made simple")
print("Ready to create amazing experiences")'''
        
        self.code_editor.insert('1.0', welcome)
        self.apply_syntax_highlighting()
        
        # Events
        self.code_editor.bind('<KeyRelease>', self.on_text_change)
    
    def setup_studio_panel(self, parent):
        """Apple-style Studio panel"""
        # Glass container  
        studio_container = tk.Frame(parent, bg="white", relief='solid', borderwidth=1)
        studio_container.pack(fill=tk.X)
        studio_container.configure(highlightbackground="#e5e5ea", highlightthickness=0)
        
        # Header
        studio_header = tk.Label(studio_container, text="Studio Integration",
                                font=('Helvetica Neue', 18, 'normal'),
                                bg="white", fg="#1d1d1f")
        studio_header.pack(pady=(25, 15))
        
        # Content
        content = tk.Frame(studio_container, bg="white")
        content.pack(fill=tk.X, padx=25, pady=(0, 25))
        
        # Connection row
        conn_frame = tk.Frame(content, bg="white")
        conn_frame.pack(fill=tk.X, pady=(0, 20))
        
        port_label = tk.Label(conn_frame, text="Studio Port",
                             font=('Helvetica Neue', 12), bg="white", fg="#1d1d1f")
        port_label.pack(side=tk.LEFT)
        
        self.port_var = tk.StringVar(value="24872")
        port_entry = tk.Entry(conn_frame, textvariable=self.port_var, width=8,
                             font=('Monaco', 12), bg="white", fg="#1d1d1f",
                             relief='solid', borderwidth=1)
        port_entry.pack(side=tk.LEFT, padx=(15, 0))
        
        test_btn = tk.Button(conn_frame, text="Test",
                            font=('Helvetica Neue', 11), bg="white", fg="#1d1d1f",
                            relief='solid', borderwidth=1, padx=12, pady=4,
                            activebackground="#f0f0f0", cursor="hand2",
                            command=self.test_studio_connection)
        test_btn.pack(side=tk.LEFT, padx=(20, 0))
        
        # Status
        self.status_var = tk.StringVar(value="Ready")
        self.status_label = tk.Label(conn_frame, textvariable=self.status_var,
                                    font=('Helvetica Neue', 12), bg="white", fg="#30d158")
        self.status_label.pack(side=tk.RIGHT)
        
        # Script name
        name_frame = tk.Frame(content, bg="white")
        name_frame.pack(fill=tk.X, pady=(0, 20))
        
        name_label = tk.Label(name_frame, text="Script Name",
                             font=('Helvetica Neue', 12), bg="white", fg="#1d1d1f")
        name_label.pack(anchor=tk.W, pady=(0, 8))
        
        self.script_name_var = tk.StringVar(value="RoHelper_Script")
        script_entry = tk.Entry(name_frame, textvariable=self.script_name_var,
                               font=('Monaco', 12), bg="white", fg="#1d1d1f",
                               relief='solid', borderwidth=1)
        script_entry.pack(fill=tk.X)
        
        # Quick actions
        actions_label = tk.Label(content, text="Quick Actions",
                                font=('Helvetica Neue', 12), bg="white", fg="#1d1d1f")
        actions_label.pack(anchor=tk.W, pady=(20, 8))
        
        actions_frame = tk.Frame(content, bg="white")
        actions_frame.pack(fill=tk.X)
        
        folder_btn = tk.Button(actions_frame, text="Open Folder",
                              font=('Helvetica Neue', 11), bg="white", fg="#1d1d1f",
                              relief='solid', borderwidth=1, padx=12, pady=4,
                              activebackground="#f0f0f0", cursor="hand2",
                              command=self.open_scripts_folder)
        folder_btn.pack(side=tk.LEFT, padx=(0, 12))
        
        refresh_btn = tk.Button(actions_frame, text="Refresh",
                               font=('Helvetica Neue', 11), bg="white", fg="#1d1d1f",
                               relief='solid', borderwidth=1, padx=12, pady=4,
                               activebackground="#f0f0f0", cursor="hand2",
                               command=self.refresh_templates)
        refresh_btn.pack(side=tk.LEFT, padx=(0, 12))
        
        help_btn = tk.Button(actions_frame, text="Help",
                            font=('Helvetica Neue', 11), bg="white", fg="#1d1d1f",
                            relief='solid', borderwidth=1, padx=12, pady=4,
                            activebackground="#f0f0f0", cursor="hand2",
                            command=self.show_help)
        help_btn.pack(side=tk.LEFT)
    
    def on_category_change(self, event=None):
        """Handle category change"""
        category = self.category_var.get()
        if category in self.templates:
            self.template_listbox.delete(0, tk.END)
            for name in self.templates[category].keys():
                self.template_listbox.insert(tk.END, name)
    
    def on_template_select(self, event=None):
        """Handle template selection"""
        selection = self.template_listbox.curselection()
        if selection:
            category = self.category_var.get()
            template_name = self.template_listbox.get(selection[0])
            
            if category in self.templates and template_name in self.templates[category]:
                template = self.templates[category][template_name]
                
                # Update description
                self.description_label.config(text=template["description"])
                
                # Load code
                self.code_editor.delete('1.0', tk.END)
                self.code_editor.insert('1.0', template["code"])
                
                # Update name
                clean_name = template_name.replace(" ", "")
                self.script_name_var.set(f"RoHelper_{clean_name}")
                
                self.apply_syntax_highlighting()
    
    def clear_editor(self):
        """Clear editor"""
        self.code_editor.delete('1.0', tk.END)
        self.update_status("Editor cleared", "#ff9f0a")
    
    def copy_to_clipboard(self):
        """Copy to clipboard"""
        code = self.code_editor.get('1.0', tk.END)
        pyperclip.copy(code)
        messagebox.showinfo("Success", "Script copied to clipboard!")
        self.update_status("Copied", "#30d158")
    
    def update_status(self, message, color):
        """Update status"""
        self.status_var.set(message)
        self.status_label.config(fg=color)
    
    def test_studio_connection(self):
        """Test Studio connection"""
        def test():
            try:
                port = int(self.port_var.get())
                url = f"http://{self.studio_host}:{port}"
                response = requests.get(f"{url}/", timeout=3)
                
                if response.status_code == 200:
                    self.root.after(0, lambda: self.update_status("Connected", "#30d158"))
                    self.root.after(0, lambda: messagebox.showinfo("Success", "Connected to Studio!"))
                else:
                    self.root.after(0, lambda: self.update_status("Failed", "#ff3b30"))
                    
            except requests.exceptions.ConnectionError:
                self.root.after(0, lambda: self.update_status("Clipboard mode", "#ff9f0a"))
                self.root.after(0, lambda: messagebox.showinfo("Info", 
                    "Using clipboard/file transfer mode.\\nThis is normal!"))
            except ValueError:
                self.root.after(0, lambda: messagebox.showerror("Error", "Invalid port"))
            except Exception as e:
                self.root.after(0, lambda: self.update_status("Error", "#ff3b30"))
        
        threading.Thread(target=test, daemon=True).start()
    
    def send_to_studio(self):
        """Send script to Studio"""
        code = self.code_editor.get('1.0', tk.END).strip()
        script_name = self.script_name_var.get().strip() or "RoHelper_Script"
        
        if not code:
            messagebox.showwarning("Warning", "No code to send!")
            return
        
        # Copy to clipboard
        pyperclip.copy(code)
        
        # Save file
        timestamp = str(int(time.time()))
        script_file = os.path.join(self.transfer_folder, f"{script_name}_{timestamp}.lua")
        with open(script_file, 'w') as f:
            f.write(f"-- Generated by RoHelper\\n-- Script: {script_name}\\n\\n{code}")
        
        # Try HTTP
        def try_http():
            try:
                port = int(self.port_var.get())
                url = f"http://{self.studio_host}:{port}/create-script"
                data = {"name": script_name, "source": code, "type": "ServerScript"}
                requests.post(url, json=data, timeout=3)
                self.root.after(0, lambda: self.update_status("HTTP sent", "#30d158"))
            except:
                pass
        
        threading.Thread(target=try_http, daemon=True).start()
        
        messagebox.showinfo("Script Ready", 
            f"Script '{script_name}' ready for Studio!\\n\\n"
            "Transfer methods used:\\n"
            "• Copied to clipboard\\n"
            f"• Saved to {script_file}\\n"
            "• HTTP attempted\\n\\n"
            "In Studio: Paste with Ctrl+V")
        
        self.update_status("Transferred", "#30d158")
    
    def setup_syntax_highlighting(self):
        """Apple-inspired syntax colors"""
        # Clean Xcode-inspired colors
        self.code_editor.tag_configure("keyword", foreground="#ad3da4", font=("Monaco", 14))  # Purple
        self.code_editor.tag_configure("string", foreground="#d12f1b", font=("Monaco", 14))   # Red
        self.code_editor.tag_configure("comment", foreground="#86868b", font=("Monaco", 13, "italic"))  # Gray
        self.code_editor.tag_configure("number", foreground="#1c00cf", font=("Monaco", 14))   # Blue
        self.code_editor.tag_configure("function", foreground="#0f68a0", font=("Monaco", 14)) # Teal
        self.code_editor.tag_configure("service", foreground="#78492a", font=("Monaco", 14))  # Brown
        self.code_editor.tag_configure("rohelper", foreground="#007aff", font=("Monaco", 14, "bold"))  # Apple blue
    
    def apply_syntax_highlighting(self):
        """Apply syntax highlighting"""
        try:
            # Clear tags
            for tag in ["keyword", "string", "comment", "number", "function", "service", "rohelper"]:
                self.code_editor.tag_remove(tag, "1.0", tk.END)
            
            content = self.code_editor.get("1.0", tk.END)
            lines = content.split('\\n')
            
            keywords = ["and", "break", "do", "else", "elseif", "end", "false", "for", 
                       "function", "if", "in", "local", "nil", "not", "or", "repeat", 
                       "return", "then", "true", "until", "while"]
            
            services = ["game", "workspace", "script", "Players", "RunService", 
                       "UserInputService", "TweenService", "ReplicatedStorage"]
            
            for line_num, line in enumerate(lines, 1):
                if "RoHelper" in line:
                    self.code_editor.tag_add("rohelper", f"{line_num}.0", f"{line_num}.{len(line)}")
                elif "--" in line:
                    comment_start = line.find("--")
                    self.code_editor.tag_add("comment", f"{line_num}.{comment_start}", f"{line_num}.{len(line)}")
                else:
                    self.highlight_words(line, line_num, keywords, services)
        except:
            pass
    
    def highlight_words(self, line, line_num, keywords, services):
        """Highlight keywords and services"""
        for match in re.finditer(r'\\b\\w+\\b', line):
            word = match.group()
            start = match.start()
            end = match.end()
            
            if word in keywords:
                self.code_editor.tag_add("keyword", f"{line_num}.{start}", f"{line_num}.{end}")
            elif word in services:
                self.code_editor.tag_add("service", f"{line_num}.{start}", f"{line_num}.{end}")
    
    def on_text_change(self, event=None):
        """Handle text changes"""
        if hasattr(self, '_highlight_id'):
            self.root.after_cancel(self._highlight_id)
        self._highlight_id = self.root.after(300, self.apply_syntax_highlighting)
    
    def generate_custom_script(self):
        """Generate custom script"""
        dialog = CustomScriptDialog(self.root)
        if dialog.result:
            self.code_editor.delete('1.0', tk.END)
            self.code_editor.insert('1.0', dialog.result)
            self.apply_syntax_highlighting()
            self.update_status("Generated", "#007aff")
    
    def open_scripts_folder(self):
        """Open scripts folder"""
        try:
            os.startfile(self.transfer_folder)
        except:
            messagebox.showinfo("Folder", f"Scripts: {os.path.abspath(self.transfer_folder)}")
    
    def refresh_templates(self):
        """Refresh templates"""
        self.on_category_change()
        messagebox.showinfo("Refreshed", "Templates updated!")
    
    def show_help(self):
        """Show help"""
        help_text = """RoHelper Help

How to Use:
1. Select category and template
2. Edit code if needed  
3. Click "Send to Studio"

Features:
• Automatic clipboard copy
• File saving
• HTTP transfer
• Syntax highlighting

Tips:
• Double-click templates
• Use clear script names
• Check Studio's ServerStorage

Made with care by RoHelper"""
        
        messagebox.showinfo("Help", help_text)
    
    def run(self):
        """Start application"""
        # Center window
        self.root.update_idletasks()
        x = (self.root.winfo_screenwidth() // 2) - (self.root.winfo_width() // 2)
        y = (self.root.winfo_screenheight() // 2) - (self.root.winfo_height() // 2)
        self.root.geometry(f"+{x}+{y}")
        
        self.update_status("Ready", "#007aff")
        self.root.mainloop()

class CustomScriptDialog:
    """Apple-style custom script dialog"""
    
    def __init__(self, parent):
        self.result = None
        self.dialog = tk.Toplevel(parent)
        self.dialog.title("Custom Script Generator")
        self.dialog.geometry("600x500")
        self.dialog.configure(bg="#f5f5f7")
        self.dialog.transient(parent)
        self.dialog.grab_set()
        
        # Center
        x = parent.winfo_x() + 100
        y = parent.winfo_y() + 50
        self.dialog.geometry(f"+{x}+{y}")
        
        self.setup_dialog()
    
    def setup_dialog(self):
        """Setup dialog"""
        # Header
        header = tk.Frame(self.dialog, bg="white", height=80)
        header.pack(fill=tk.X)
        header.pack_propagate(False)
        
        # Shadow line
        tk.Frame(self.dialog, bg="#e5e5ea", height=1).pack(fill=tk.X)
        
        header_label = tk.Label(header, text="Custom Script Generator", 
                               font=('Helvetica Neue', 20), 
                               bg="white", fg="#1d1d1f")
        header_label.pack(pady=25)
        
        # Main content
        main = tk.Frame(self.dialog, bg="#f5f5f7")
        main.pack(fill=tk.BOTH, expand=True, padx=30, pady=30)
        
        # Config panel
        config = tk.Frame(main, bg="white", relief='solid', borderwidth=1)
        config.pack(fill=tk.X, pady=(0, 20))
        config.configure(highlightbackground="#e5e5ea")
        
        config_content = tk.Frame(config, bg="white")
        config_content.pack(fill=tk.X, padx=25, pady=20)
        
        # Type
        tk.Label(config_content, text="Script Type", 
                font=('Helvetica Neue', 13), bg="white", fg="#1d1d1f").pack(anchor=tk.W, pady=(0, 8))
        
        self.script_type = tk.StringVar(value="basic")
        type_combo = ttk.Combobox(config_content, textvariable=self.script_type,
                                 values=["basic", "gui", "tool", "effect"], 
                                 state="readonly", font=('Helvetica Neue', 12))
        type_combo.pack(fill=tk.X, pady=(0, 15))
        type_combo.bind('<<ComboboxSelected>>', self.update_preview)
        
        # Name
        tk.Label(config_content, text="Object Name", 
                font=('Helvetica Neue', 13), bg="white", fg="#1d1d1f").pack(anchor=tk.W, pady=(0, 8))
        
        self.object_name = tk.StringVar(value="MyObject")
        name_entry = tk.Entry(config_content, textvariable=self.object_name, 
                             font=('Monaco', 12), bg="white", fg="#1d1d1f",
                             relief='solid', borderwidth=1)
        name_entry.pack(fill=tk.X)
        name_entry.bind('<KeyRelease>', self.update_preview)
        
        # Preview
        preview_frame = tk.Frame(main, bg="white", relief='solid', borderwidth=1)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 20))
        
        tk.Label(preview_frame, text="Preview", 
                font=('Helvetica Neue', 15), bg="white", fg="#1d1d1f").pack(pady=(15, 10))
        
        self.preview_text = tk.Text(preview_frame, height=12, font=("Monaco", 11), 
                                   bg="#fbfbfd", fg="#1d1d1f", state=tk.DISABLED,
                                   relief="flat", borderwidth=0, padx=20, pady=10)
        self.preview_text.pack(fill=tk.BOTH, expand=True, padx=1, pady=(0, 1))
        
        # Buttons
        button_frame = tk.Frame(main, bg="#f5f5f7")
        button_frame.pack(fill=tk.X)
        
        cancel_btn = tk.Button(button_frame, text="Cancel",
                              font=('Helvetica Neue', 12), bg="white", fg="#1d1d1f",
                              relief='solid', borderwidth=1, padx=20, pady=8,
                              activebackground="#f0f0f0", cursor="hand2",
                              command=self.dialog.destroy)
        cancel_btn.pack(side=tk.RIGHT, padx=(15, 0))
        
        generate_btn = tk.Button(button_frame, text="Generate",
                                font=('Helvetica Neue', 12), bg="#007aff", fg="white",
                                relief='flat', borderwidth=0, padx=25, pady=10,
                                activebackground="#0051d5", cursor="hand2",
                                command=self.generate)
        generate_btn.pack(side=tk.RIGHT)
        
        self.update_preview()
    
    def update_preview(self, *args):
        """Update preview"""
        script_type = self.script_type.get()
        object_name = self.object_name.get() or "MyObject"
        
        if script_type == "basic":
            preview = f'''-- Basic Script for {object_name}
print("Hello from {object_name}")
print("Created with RoHelper")

local message = "This is {object_name}"
print(message)'''
        elif script_type == "gui":
            preview = f'''-- GUI Script for {object_name}
local Players = game:GetService("Players")
local player = Players.LocalPlayer

local gui = Instance.new("ScreenGui")
gui.Name = "RoHelper_{object_name}"
gui.Parent = player.PlayerGui

print("GUI created for {object_name}")'''
        elif script_type == "tool":
            preview = f'''-- Tool Script for {object_name}
local tool = script.Parent
tool.Name = "RoHelper_{object_name}"

tool.Activated:Connect(function()
    print("{object_name} activated")
end)'''
        else:
            preview = f'''-- {script_type.title()} Script for {object_name}
print("{object_name} script ready")
print("Created with RoHelper")'''
        
        self.preview_text.config(state=tk.NORMAL)
        self.preview_text.delete('1.0', tk.END)
        self.preview_text.insert('1.0', preview)
        self.preview_text.config(state=tk.DISABLED)
    
    def generate(self):
        """Generate script"""
        script_type = self.script_type.get()
        object_name = self.object_name.get() or "MyObject"
        
        if script_type == "basic":
            self.result = f'''-- Basic Script for {object_name} (Generated by RoHelper)
print("Hello from {object_name}!")
print("Created with RoHelper - Professional Roblox scripting")

-- Add your custom code here
local message = "Welcome to {object_name}"
print(message)

-- Example: Create a simple part
local part = Instance.new("Part")
part.Name = "{object_name}_Part"
part.Size = Vector3.new(4, 4, 4)
part.Position = Vector3.new(0, 10, 0)
part.BrickColor = BrickColor.new("Bright blue")
part.Material = Enum.Material.Glass
part.Parent = workspace

print("Script and part created successfully!")'''
        
        elif script_type == "gui":
            self.result = f'''-- GUI Script for {object_name} (Generated by RoHelper)
local Players = game:GetService("Players")
local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

-- Create clean GUI
local screenGui = Instance.new("ScreenGui")
screenGui.Name = "RoHelper_{object_name}"
screenGui.Parent = playerGui

-- Main frame with glass effect
local mainFrame = Instance.new("Frame")
mainFrame.Size = UDim2.new(0, 360, 0, 240)
mainFrame.Position = UDim2.new(0.5, -180, 0.5, -120)
mainFrame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
mainFrame.BackgroundTransparency = 0.05
mainFrame.BorderSizePixel = 0
mainFrame.Parent = screenGui

-- Rounded corners
local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 12)
corner.Parent = mainFrame

-- Title
local title = Instance.new("TextLabel")
title.Size = UDim2.new(1, -40, 0, 50)
title.Position = UDim2.new(0, 20, 0, 20)
title.BackgroundTransparency = 1
title.Text = "{object_name} Interface"
title.TextColor3 = Color3.fromRGB(29, 29, 31)
title.TextSize = 20
title.Font = Enum.Font.SourceSans
title.Parent = mainFrame

-- Action button
local button = Instance.new("TextButton")
button.Size = UDim2.new(0, 180, 0, 40)
button.Position = UDim2.new(0.5, -90, 0.75, -20)
button.BackgroundColor3 = Color3.fromRGB(0, 122, 255)
button.Text = "Click Me"
button.TextColor3 = Color3.fromRGB(255, 255, 255)
button.TextSize = 16
button.BorderSizePixel = 0
button.Parent = mainFrame

local buttonCorner = Instance.new("UICorner")
buttonCorner.CornerRadius = UDim.new(0, 6)
buttonCorner.Parent = button

button.MouseButton1Click:Connect(function()
    print("{object_name} button clicked!")
    button.Text = "Clicked!"
    wait(1)
    button.Text = "Click Me"
end)

print("Modern GUI created for {object_name}")'''
        
        elif script_type == "tool":
            self.result = f'''-- Tool Script for {object_name} (Generated by RoHelper)
local tool = script.Parent
tool.Name = "RoHelper_{object_name}"
tool.RequiresHandle = true
tool.CanBeDropped = true

local Players = game:GetService("Players")
local player = Players.LocalPlayer

local function onEquipped()
    print("{object_name} equipped!")
    -- Add equip effects here
end

local function onUnequipped()
    print("{object_name} unequipped!")
    -- Add unequip effects here
end

local function onActivated()
    print("{object_name} activated!")
    
    -- Example: Create a small effect
    if player.Character and player.Character:FindFirstChild("HumanoidRootPart") then
        local rootPart = player.Character.HumanoidRootPart
        local effectPos = rootPart.Position + rootPart.CFrame.LookVector * 6
        
        local effect = Instance.new("Part")
        effect.Size = Vector3.new(1, 1, 1)
        effect.Position = effectPos
        effect.Material = Enum.Material.Glass
        effect.BrickColor = BrickColor.new("Bright blue")
        effect.Anchored = true
        effect.Parent = workspace
        
        game:GetService("Debris"):AddItem(effect, 2)
    end
end

tool.Equipped:Connect(onEquipped)
tool.Unequipped:Connect(onUnequipped)
tool.Activated:Connect(onActivated)

print("Tool {object_name} created with RoHelper")'''
        
        else:
            self.result = f'''-- {script_type.title()} Script for {object_name} (Generated by RoHelper)
print("{object_name} script created with RoHelper")
print("Professional Roblox development made simple")

-- Add your {script_type} code here
local {object_name.lower()}Config = {{
    name = "{object_name}",
    type = "{script_type}",
    version = "1.0",
    author = "RoHelper"
}}

print("Configuration loaded:", {object_name.lower()}Config.name)'''
        
        self.dialog.destroy()

def main():
    """Launch RoHelper"""
    print("Starting RoHelper...")
    print("Apple-inspired design")
    
    app = RoHelper()
    app.run()

if __name__ == "__main__":
    main()