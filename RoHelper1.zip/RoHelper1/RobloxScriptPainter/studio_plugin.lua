-- Roblox Studio Plugin for Script Generator
-- This plugin receives HTTP requests from the Python GUI and creates scripts in Studio

local HttpService = game:GetService("HttpService")
local Selection = game:GetService("Selection")
local PluginGuiService = game:GetService("PluginGuiService")

-- Create plugin toolbar and button
local toolbar = plugin:CreateToolbar("Script Generator")
local toggleButton = toolbar:CreateButton(
    "Toggle Server",
    "Start/Stop HTTP server for script generation",
    "rbxasset://textures/DevConsole/LuaSourceIcon.png"
)

-- Plugin state
local isServerRunning = false
local httpServer = nil
local serverThread = nil

-- UI Elements
local widget = nil
local statusLabel = nil

-- Create the plugin widget
local widgetInfo = DockWidgetPluginGuiInfo.new(
    Enum.InitialDockState.Float,
    false,  -- Initially disabled
    false,  -- Don't override previous state
    300,    -- Floating size X
    200,    -- Floating size Y
    250,    -- Minimum width
    150     -- Minimum height
)

widget = plugin:CreateDockWidgetPluginGui("ScriptGeneratorWidget", widgetInfo)
widget.Title = "Script Generator"

-- Create UI
local function createUI()
    -- Main frame
    local mainFrame = Instance.new("Frame")
    mainFrame.Size = UDim2.new(1, 0, 1, 0)
    mainFrame.BackgroundColor3 = Color3.fromRGB(46, 46, 46)
    mainFrame.Parent = widget
    
    -- Title
    local title = Instance.new("TextLabel")
    title.Size = UDim2.new(1, -20, 0, 30)
    title.Position = UDim2.new(0, 10, 0, 10)
    title.BackgroundTransparency = 1
    title.Text = "Script Generator Plugin"
    title.TextColor3 = Color3.fromRGB(255, 255, 255)
    title.TextScaled = true
    title.Font = Enum.Font.SourceSansBold
    title.Parent = mainFrame
    
    -- Status label
    statusLabel = Instance.new("TextLabel")
    statusLabel.Size = UDim2.new(1, -20, 0, 25)
    statusLabel.Position = UDim2.new(0, 10, 0, 50)
    statusLabel.BackgroundTransparency = 1
    statusLabel.Text = "Server Status: Stopped"
    statusLabel.TextColor3 = Color3.fromRGB(255, 100, 100)
    statusLabel.TextScaled = true
    statusLabel.Font = Enum.Font.SourceSans
    statusLabel.Parent = mainFrame
    
    -- Instructions
    local instructions = Instance.new("TextLabel")
    instructions.Size = UDim2.new(1, -20, 0, 80)
    instructions.Position = UDim2.new(0, 10, 0, 85)
    instructions.BackgroundTransparency = 1
    instructions.Text = "1. Click 'Toggle Server' to start\n2. Run the Python GUI app\n3. Generate scripts and send to Studio\n4. Scripts will appear in ServerStorage"
    instructions.TextColor3 = Color3.fromRGB(200, 200, 200)
    instructions.TextScaled = true
    instructions.Font = Enum.Font.SourceSans
    instructions.TextYAlignment = Enum.TextYAlignment.Top
    instructions.Parent = mainFrame
end

-- HTTP Server simulation (Studio doesn't have real HTTP server, so we'll use a different approach)
local function startServer()
    if isServerRunning then
        return
    end
    
    isServerRunning = true
    statusLabel.Text = "Server Status: Running on port 24872"
    statusLabel.TextColor3 = Color3.fromRGB(100, 255, 100)
    toggleButton.Name = "Stop Server"
    
    -- We'll use a different approach - file monitoring
    -- Create a folder for script transfer
    local scriptFolder = game.ServerStorage:FindFirstChild("GeneratedScripts")
    if not scriptFolder then
        scriptFolder = Instance.new("Folder")
        scriptFolder.Name = "GeneratedScripts"
        scriptFolder.Parent = game.ServerStorage
    end
    
    print("Script Generator Server Started - Monitoring for new scripts")
end

local function stopServer()
    if not isServerRunning then
        return
    end
    
    isServerRunning = false
    statusLabel.Text = "Server Status: Stopped"
    statusLabel.TextColor3 = Color3.fromRGB(255, 100, 100)
    toggleButton.Name = "Start Server"
    
    print("Script Generator Server Stopped")
end

-- Create script from external data
local function createScriptFromData(scriptData)
    local scriptName = scriptData.name or "GeneratedScript"
    local scriptSource = scriptData.source or "print('Empty script')"
    local scriptType = scriptData.type or "Script"
    
    -- Create the script
    local newScript
    if scriptType == "LocalScript" then
        newScript = Instance.new("LocalScript")
    else
        newScript = Instance.new("Script")
    end
    
    newScript.Name = scriptName
    newScript.Source = scriptSource
    
    -- Place in ServerStorage for organization
    local scriptFolder = game.ServerStorage:FindFirstChild("GeneratedScripts")
    if not scriptFolder then
        scriptFolder = Instance.new("Folder")
        scriptFolder.Name = "GeneratedScripts"
        scriptFolder.Parent = game.ServerStorage
    end
    
    newScript.Parent = scriptFolder
    
    -- Select the new script
    Selection:Set({newScript})
    
    print("Created script: " .. scriptName)
    return newScript
end

-- Toggle server
local function toggleServer()
    if isServerRunning then
        stopServer()
    else
        startServer()
    end
end

-- Button click handler
toggleButton.Click:Connect(toggleServer)

-- Create UI when plugin loads
createUI()

-- Plugin cleanup
plugin.Unloading:Connect(function()
    if isServerRunning then
        stopServer()
    end
    if widget then
        widget:Destroy()
    end
end)

-- Alternative method: Monitor clipboard for scripts
local lastClipboard = ""
spawn(function()
    while true do
        if isServerRunning then
            -- Check for special clipboard format
            local success, clipboard = pcall(function()
                return game:GetService("GuiService"):GetErrorMessage() -- This is a workaround
            end)
            
            -- We'll use a different approach - command bar execution
            -- Users can paste special commands that trigger script creation
        end
        wait(1)
    end
end)

-- Export function for external use
_G.CreateScriptFromPython = function(scriptData)
    if isServerRunning then
        return createScriptFromData(scriptData)
    else
        warn("Script Generator server is not running!")
        return nil
    end
end

print("Script Generator Plugin Loaded!")
print("Click the 'Toggle Server' button in the toolbar to start receiving scripts")